from urllib import request
import time
import csv
from lxml import etree

class MaoyanSpider(object):
    def __init__(self):
        self.baseurl = 'https://maoyan.com/board/4?offset='
        self.headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'}
        # 爬取页数计数
        self.page = 1

    # 获取页面
    def get_page(self,url):
        req = request.Request(url,headers=self.headers)
        res = request.urlopen(req)
        html = res.read().decode('utf-8')
        # 直接调用解析函数
        self.parse_page(html)

    # 解析页面
    def parse_page(self,html):
        parse_html = etree.HTML(html)
        # 基准xpath,匹配每个电影信息节点对象列表
        dd_list = parse_html.xpath('//dl[@class="board-wrapper"]/dd')
        # dd_list : [<element dd at xxx>,<...>]
        for dd in dd_list:
            name = dd.xpath('./a/@title')[0].strip()
            star = dd.xpath('.//p[@class="star"]/text()')[0].strip()
            time = dd.xpath('.//p[@class="releasetime"]/text()')[0].strip()
            print([name,star,time])


    # 保存数据(存到csv文件)
    def write_page(self,r_list):
        # r_list : [(),(),()]
        with open('猫眼.csv','a') as f:
            writer = csv.writer(f)
            for rt in r_list:
                film = [
                    rt[0].strip(),
                    rt[1].strip(),
                    rt[2].strip()
                ]
                writer.writerow(film)


    # 主函数
    def main(self):
        # 用range函数可获取某些查询参数的值
        for offset in range(0,41,10):
            url = self.baseurl + str(offset)
            self.get_page(url)
            print('第%d页爬取成功' % self.page)
            self.page += 1
            time.sleep(1)

if __name__ == '__main__':
    spider = MaoyanSpider()
    spider.main()






















