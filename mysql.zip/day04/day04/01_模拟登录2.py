import requests

# 把用户名和密码信息post到一个URL
post_url = 'http://www.renren.com/PLogin.do'
# 键为input标签中name的值
post_data = {
    'email' : '13603263409',
    'password' : 'zhanshen001'
}
headers = {
    'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36',
    'Referer' : 'http://www.renren.com/'
}
# 实例化session对象
session = requests.session()
session.post(post_url,data=post_data,headers=headers)
# 访问个人主页URL地址
url = 'http://www.renren.com/967469305/profile'
res = session.get(url,headers=headers)
print(res.text)




