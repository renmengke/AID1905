import requests
import time
from hashlib import md5
import random
import json

# url F12 -> translate_o -> post
url = 'http://fanyi.youdao.com/translate_o?smartresult=dict&smartresult=rule'
# headers
headers = {
    'Cookie' : 'P_INFO=sisuo321; td_cookie=18446744071955357428; OUTFOX_SEARCH_USER_ID=-181078558@10.169.0.83; OUTFOX_SEARCH_USER_ID_NCOO=1868644683.863983; JSESSIONID=aaaxATKlt6l2bbsjsDTPw; SESSION_FROM_COOKIE=unknown; ___rl__test__cookies=1556615192487',
    'Referer' : 'http://fanyi.youdao.com/',
    'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36'
}
proxies = {'http':'http://125.32.177.235:8080'}
# Input word
key = input('Input word:')
# salt
salt = str(int(time.time()*1000)) + \
	        str(random.randint(0,10))

# sign
string = "fanyideskweb" + key + salt + \
                 "@6f#X3=cCuncYssPsuRUE"
s = md5()
s.update(string.encode())
sign = s.hexdigest()

# ts
ts = str(int(time.time()*1000))
# Form Data
data = {
    'i': key,
    'from': 'AUTO',
    'to': 'AUTO',
    'smartresult': 'dict',
    'client': 'fanyideskweb',
    'salt': salt,
    'sign': sign,
    'ts': ts,
    'bv': 'cf156b581152bd0b259b90070b1120e6',
    'doctype': 'json',
    'version': '2.1',
    'keyfrom': 'fanyi.web',
    'action': 'FY_BY_REALTlME'
}

res = requests.post(url,data=data,headers=headers)
res.encoding = 'utf-8'
# html为一个json格式的字符串
html = res.text
# 把json格式的字符串转为python数据类型
html = json.loads(html)

result = html['translateResult'][0][0]['tgt']
print(result)

# {'type': 'en2zh-CHS',
#  'translateResult':
#      [[{'tgt': '你好', 'src': 'hello'}]], 'smartResult': {'type': 1, 'entries': ['', 'n. 表示问候， 惊奇或唤起注意时的用语\r\n', 'int. 喂；哈罗\r\n', 'n. (Hello)人名；(法)埃洛\r\n']}, 'errorCode': 0}










